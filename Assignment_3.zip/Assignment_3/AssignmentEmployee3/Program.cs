﻿using DocumentFormat.OpenXml.ExtendedProperties;
using Microsoft.Azure.Management.ResourceManager.Fluent.Core;
using System;

namespace AssignmentEmployee3
{

    class Employee
    {

        public int EmpId;
        public string EmpName;
        public double basic_Salary = 30000;
        public double HRA;
        public double TA;
        public double DA;
        public double PF;
        public double TDS;
        public double NetSalary;
        public double GrossSalary;
        public double km;

        public void getdetails()
        {
            Console.WriteLine("Enter Manager ID");
            EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Manager Name");
            EmpName = Console.ReadLine();


        }
        public void getkmdetails()
        {
            Console.WriteLine("Enter MarketingExecutive ID");
            EmpId = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter MarketingExecutive Name");
            EmpName = Console.ReadLine();
            Console.WriteLine("Enter no of km you traveled");
            km = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter MarketingExecutive Id is :" + EmpId);
            Console.WriteLine("Enter MarketingExecutive Nameis:" + EmpName);

        }
        public void display()
        {
            Console.WriteLine("Enter Manager ID is:" + EmpId);
            Console.WriteLine("Enter Manager Name is: " + EmpName);

        }

        public void calculateSalary()
        {
            Console.WriteLine("your basic Salary is :" + basic_Salary);
        }

        class Manager : Employee
        {
            public void getEmpdetails()
            {
                getdetails();
                //base.getdetails();
                base.display();
                base.calculateSalary();

            }
            public void calculateSalary()
            {
                double netsal;
                double grossal;
                grossal = base.basic_Salary + (base.basic_Salary * 0.08) + (base.basic_Salary * 0.13) + (base.basic_Salary * 0.03);
                Console.WriteLine("Your Gross Salary  is: " + grossal);
                netsal = grossal - 500;
                Console.WriteLine("Your Net Salary  is: " + netsal);
                Console.WriteLine("\n\n\n");


            }

        }
        class Marktingexc : Employee
        {
            public void getEmpdetails()
            {
                base.getkmdetails();
                base.calculateSalary();
            }
            public void calculateSalary()
            {
                double netsal;
                double grossal;
                grossal = base.basic_Salary + (base.km / 5) + 1000;
                Console.WriteLine("Your Gross Salary  is: " + grossal);
                netsal = grossal - 500;
                Console.WriteLine("Your Net Salary  is: " + netsal);
                Console.WriteLine("\n\n\n");



            }


        }


        class Program
        {
            static void Main(string[] args)
            {
                {
                    Manager mg = new Manager();
                    mg.getEmpdetails();
                    mg.calculateSalary();
                    Marktingexc mk = new Marktingexc();
                    mk.getEmpdetails();
                    mk.calculateSalary();

                    Console.ReadKey();

                }
            }
        }
    }
}




