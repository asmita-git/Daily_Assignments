﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssignmentCal
{
    class circumference
    {
		static double circumferenc(double r)
		{

			double PI = 3.1415;
			double cir = 2 * PI * r;
			return cir;
		}


		public static void Main()
		{

			double r = 5;
			double result =
				Math.Round(circumferenc(r)
							* 1000) / 1000.0;

			Console.WriteLine("Circumference = "
									+ result);
		}
	}
}
