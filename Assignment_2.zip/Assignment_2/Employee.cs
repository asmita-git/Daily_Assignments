﻿using System;

namespace AssignmentEmployee
{
     class Employee
    {

        public int EmpNo { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }
        public double HRA { get; set; }
        public double TA { get; set; }
        public double DA { get; set; }
        public double PF { get; set; }
        public double TDS { get; set; }
        public double NetSalary { get; set; }
        public double GrossSalary { get; set; }

        public Employee(int EmpNo, string EmpName, double Sal)
        {
            Console.WriteLine("Enter the EmpName");
            EmpName = Console.ReadLine();

            Console.WriteLine("Enter the EmpNo");
            EmpNo = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter the salary");
            Salary = Convert.ToDouble(Console.ReadLine());


            if (Salary < 5000)
            {
                HRA = (Salary * 10) / 100;
                TA = (Salary * 5) / 100;
                DA = (Salary * 15) / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
            else if (Salary < 10000)
            {
                HRA = (Salary * 15) / 100;
                TA = (Salary * 10) / 100;
                DA = (Salary * 20) / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
            else if (Salary < 15000)
            {
                HRA = (Salary * 20) / 100;
                TA = (Salary * 15) / 100;
                DA = (Salary * 25) / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
            else if (Salary < 20000)
            {
                HRA = (Salary * 25) / 100;
                TA = (Salary * 20) / 100;
                DA = (Salary * 30) / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
            else
            {
                HRA = (Salary * 30) / 100;
                TA = (Salary * 25) / 100;
                DA = (Salary * 35) / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }

        }
        public void calculateSalary()
        {
            PF = GrossSalary * 10 / 100;
            TDS = GrossSalary * 18 / 100;
            NetSalary = GrossSalary - (PF + TDS);
        }
        public double GrossSal
        {
            get { return GrossSalary; }
        }
        static void Main(string[] args)
        {
            Employee Emp = new Employee(1, "Asmita", 7000);

            Emp.calculateSalary();
            Console.WriteLine(Emp.GrossSalary);
            Console.WriteLine(Emp.NetSalary);
            Console.ReadKey();







        }
    }
}
