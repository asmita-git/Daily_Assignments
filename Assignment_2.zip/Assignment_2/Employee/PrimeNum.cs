﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Employee
{
    class PrimeNum
    {
       public static void Main()
       {
            int n, a= 0;
            Console.WriteLine("Enter a number");
            n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                if (n % i == 0)
                {
                    a++;
                }
            }
            if (a==2 ) 
            {
                    Console.WriteLine(n +" is prime number");
                    
                }
                else
                {
                    Console.WriteLine(n + " is not prime number");
                }


       
        
                Console.ReadLine();
       }    


    }
}
